@extends('layouts.dbadmin')

@section('content')
<div class="inventori-container">
  <div class="inventori-header">
    <h4>Login Terlebih Dahulu</h4>
  </div>
@endsection

@push('scripts')
<script src="{{ asset('js/script.js') }}"></script>
@endpush